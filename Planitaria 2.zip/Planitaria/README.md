# Planitaria Update Package - 15 MAY 2025

## Instructions
1. Download and unzip this package.
2. Replace your local Planitaria folder in the GitHub repo:
   https://github.com/WylieH2SC/plan-the-beast/tree/main
3. Commit and push the updated folder.

## Included Files
- All core logic
- UI + Theme structure
- Metadata and continuity files
