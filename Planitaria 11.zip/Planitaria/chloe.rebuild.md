# Planitaria 1.0 Engine Rebuild Instructions

To rebuild:
1. Install Node.js v18+ and Vite.
2. Run `npm install` and `npm run dev`.
3. All source files listed in chloe.hashmap.json.

Canvas, drag-drop tray, and panel system are included in this build.
